Run from directory with all files inside including project1.py, test.csv, and partition-2.txt

python3 project1.py --dataset test.csv --input partition-2.txt --output partition-3.txt